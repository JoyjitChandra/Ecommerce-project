import React from 'react'
import {Signout} from '../../Action/AUTH.ACTION'
import {useDispatch} from 'react-redux'

export default function Logout() {
    
    const dispatch = useDispatch();
    dispatch(Signout())
    return (
        <div>
            
        </div>
    ) 
}
