import React,{useState} from 'react'
import './login.css';
import {Link} from 'react-router-dom'
import  {useDispatch} from 'react-redux';
import {signIn} from '../../../Action/AUTH.ACTION';
import {Form,Button} from "react-bootstrap";
import { MDBContainer, MDBRow, MDBCol, MDBInput, MDBBtn } from 'mdbreact';
export default function Login() {
    let [istate,fstate]=useState({email:"",password:""},{err:""})
    const dispatchMethod = useDispatch()
    const handleChange=(event)=>{
        fstate({...istate,[event.target.name]:event.target.value})
    }
    const SubmitHandler=(e)=>{
        e.preventDefault()
        console.log("form submitted",istate);
            let userdata=istate;
            console.log("userdata",userdata);
           dispatchMethod(signIn(userdata));

        }


    
    return (
        <>
            <div className='container'>
                <form className="frmlogin" onSubmit={SubmitHandler}>
                    <h1>Sign in</h1>
                <label className="l1">Email ID</label>
                    <input type="email" name="email" placeholder='Enter E-mail Id' onChange={handleChange}/> <br/> 
                <label className="l1">Password</label>
                <input type="password" name="password" placeholder='Password' onChange={handleChange}/> <br/> 
                <button className='submitbtn' type="submit" id="sb" name="submit">Login</button> 
                {/* <a as={Link} to='/reg'>Not registered? Click here!</a> */}
                {/* {istate.err ? (<p>{istate.err}</p>):null} */}
                
            </form>
            </div> 
         {/* <MDBContainer>
  <MDBRow>
    <MDBCol md="6">
      <form>
        <p className="h5 text-center mb-4">Sign in</p>
        <div className="grey-text">
          <MDBInput label="Type your email" icon="envelope" group type="email" validate error="wrong"
            success="right" type="email" name="email" onChange={handleChange} />
          <MDBInput label="Type your password" icon="lock" group type="password" validate type="password" name="password" onChange={handleChange} />
        </div>
        <div className="text-center">
          <MDBBtn>Login</MDBBtn>
        </div>
      </form>
    </MDBCol>
  </MDBRow>
</MDBContainer>  */}

        </>
    )
}