import React,{useState} from 'react'
import { useHistory } from "react-router-dom";
import './reg.css'
import  {useDispatch} from 'react-redux';
import {signUp}  from  '../../../Action/AUTH.ACTION'
export default function Reg() {
    let history=useHistory()
    console.log(history);
    const dispatchMethod = useDispatch()
    let [istate,fstate]=useState({})
    const handleChange=(event)=>{
        //console.log("NEW INPUT");
        //console.log("istate-",istate);
        fstate({...istate,[event.target.name]:event.target.value})
       // console.log("isErr-",isErr);
    }

        const SubmitHandler=(e)=>{
            e.preventDefault();
            const x=istate;
            console.log(x);
            dispatchMethod(signUp(x));

        }


    return (
        <>
        <div className='container'>
            <form className="frmreg" onSubmit={SubmitHandler}>
                <h1>SIGN UP/REGISTER</h1>
                    <label htmlFor="fname" className="l1">First name:</label>
                <input type="text" id="fname" placeholder='first name' name="firstname" onChange={handleChange}/>
                <br/>
                    <label htmlFor="lname"  className="l1">Last name:</label>
                <input type="text" id="lname" placeholder='last name' name="lastname" onChange={handleChange}/>
                <br/>
                    <label className="l1">Email ID</label>
                <input type="email" name="email" placeholder='eg: abc@gmail.com' onChange={handleChange}/>
                <br/>
                    <label className="l1">Password</label>
                <input type="password" name="password" placeholder='password' onChange={handleChange}/>
                <br/>
                <button className='submitbtn' type="submit" id="sb" name="submit">Register</button>
            </form>
            </div>
        </>
    )
}