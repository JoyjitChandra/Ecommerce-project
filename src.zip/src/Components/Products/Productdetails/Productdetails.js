import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { ProductDet } from '../../../Action/ProductAction';
import { Container, Row, Col,Card,Button } from "react-bootstrap";
import {Link, useHistory} from 'react-router-dom'
import {AddToCart} from '../../../Action/CartAction'
import '../../../content.css'
import './productdetails.css'
export default function ProductDetails({match}) {
    const abc=match.params.pid;
    console.log(match);
    const history= useHistory()
  const DispatchMethod = useDispatch();
  const ProductDesciption = useSelector((state) => state.productData);
  console.log(ProductDesciption);
 const pdetails= ProductDesciption.ProductDetails
 const spec_cat= ProductDesciption.Specific_Category.find(({id})=>id==match.params.pid)
 console.log(spec_cat);
//  const prod=product.products.find(({id})=>id==props.match.params.id)
useEffect(
    () => {
    DispatchMethod(ProductDet(abc));
    },
    
    [DispatchMethod]);
    const goToCart=()=>{
      DispatchMethod(AddToCart(spec_cat))
      console.log(spec_cat);
    }
    const Buy=()=>{
      DispatchMethod(AddToCart(spec_cat))
      history.push('/cart')
    }
  return (
    <div>
        <Container className='contents'>
          <Row>
              <Col >
                <Card className='crd'>
                  <Container>
                  <Row>
                    <Col lg={6}>
                <Card.Img className='crd_img' variant="top" className="p_image" src={spec_cat.image} />
                </Col>
                  <Col>
                <Card.Body>
                  <Card.Title>{spec_cat.title}</Card.Title>
                  <h6>{spec_cat.description}</h6>
                 <h1> Rs:{spec_cat. price}/-</h1>
                  <Button variant="primary" onClick={()=>{goToCart()}}>Add To Cart</Button>
                  <>
                  <Button variant="primary" onClick={()=>{Buy()}}>Buy</Button>
                </>
                </Card.Body>
                </Col>
                </Row>
                </Container>
              </Card>
            </Col> 
          </Row>
        </Container>
    </div>
  );
}