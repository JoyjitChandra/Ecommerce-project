import React, { useEffect,useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { ProductCate } from '../../../Action/ProductAction';
import { Container, Row, Col,Card,Button } from "react-bootstrap";
import {Link, useHistory} from 'react-router-dom'
import Footer from '../../../Layouts/footer'
import Layout from '../../../Layouts/Layout'
//import '../productstyle.css'
import '../../../content.css'
import { Dropdown,DropdownButton} from "react-bootstrap";
import { render } from "@testing-library/react";
export default function Productcategory() {
  const [category,setCategory] = useState('Categories')
  const DispatchMethod = useDispatch();
  const ProductCategory = useSelector((state) => state.productData);
  console.log(ProductCategory);
  useEffect(() => {
    DispatchMethod(ProductCate());
  },[DispatchMethod]);
  useEffect(()=>{

  })
  return (

    <div className='margin'>
      {/* <Container>
     <Row >
      {ProductCategory.AllCategories.map((e) => (
        <Col  lg={3} md={4} sm={6}>
      <Card style={{ width: '15rem',height:'8rem' ,marginTop:'-2rem'}} className='cards'>

  <Card.Body className='cardContent'>
    <Card.Title>{e}</Card.Title>
    <Button variant="dark" style={{maarginTop:'-1rem'}} bsStyle="info" as={Link} to={`/catDetails/${e}`}>Click</Button>
  </Card.Body>
</Card>
      </Col>
      ))}
      </Row> 
      </Container> */}
      {/* <div className='container contents'>
        <div className='row'>
        {ProductCategory.AllCategories.map((e,index) => (
          <div className='col-lg-3 col-md-3 col-sm-6'>
      <div className="card" key={index} style="width: 18rem;">
  <img className="card-img-top" src="" alt="Card image cap"/> 
  <div className="card-body">
    <h5 className="card-title">{e}</h5>
     <p className="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p> 
    <a href="#" className="btn btn-primary" as={Link} to={`/catDetails/${e}`}>Click</a>
  </div>
</div>
</div>
))}
</div>
</div> */}
 
<DropdownButton className='dropbtn' id="dropdown-basic-button" title={category}>
{ProductCategory.AllCategories.map((e,index) => (
            <Dropdown.Item  className="login" href={`/catDetails/${e}`} >{e}</Dropdown.Item>))}
          </DropdownButton>
    </div>

  );
}
 