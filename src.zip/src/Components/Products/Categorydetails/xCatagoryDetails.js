import React,{useEffect} from 'react'
import {useParams,useHistory} from 'react-router-dom'
import {useDispatch, useSelector} from 'react-redux';
import {Specificdata} from '../../../Action/ProductAction'
import { Container, Row, Col,Card,Button } from "react-bootstrap";
import '../../../content.css'

export default function CatagoryDetails({match}) {
    const Category = useSelector((state) => state.productData);
    console.log(Category);
    const cname = match.params.cname;
    console.log(cname);
    const dispatchMethod3 = useDispatch();
    useEffect(()=>{
        dispatchMethod3(Specificdata(cname));
    },[dispatchMethod3])
    return (
        <div>
          <div className='contents'>
          <h1>{cname}</h1>
            <Container>
          <Row>
      {Category.Specific_Category.map((e) => (
        
        <Col>
      <Card style={{ width: '18rem' }}>
  {/* <Card.Img variant="top" src="holder.js/100px180" /> */}
  <Card.Body>
    <Card.Title>{e.id}</Card.Title>
    <Card.Text>
    {e.title}
    </Card.Text>
    <Button variant="primary">Buy</Button>
  </Card.Body>
</Card>
      </Col>
          
      ))}
      </Row>
        </Container>
        </div>
        </div>
    )
}
