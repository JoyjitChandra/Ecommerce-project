import React,{useEffect} from 'react'
import {useDispatch, useSelector} from 'react-redux';
import {Specificdata} from '../../../Action/ProductAction'
import { Container, Row, Col,Card,Button } from "react-bootstrap";
import {Link} from 'react-router-dom'
import '../../../content.css'
import { Autorenew } from '@material-ui/icons';
import CartProdIncDcs from '../../../Action/CartAction';


export default function CatagoryDetails({match}) {
    const Category = useSelector((state) => state.productData);
    console.log(Category);
    const cname = match.params.cname;
    console.log(cname);
    const dispatchMethod3 = useDispatch();
    useEffect(()=>{
        dispatchMethod3(Specificdata(cname));
    },[dispatchMethod3])
    return (
        <div>
          
            <Container className='contents'>
          <Row>
      {Category.Specific_Category.map((e) => (
        
        <Col lg={4} md={4} sm={6}>
        <Card className='cards' style={{ width: '22rem',height:'25rem' , margin:'1rem'}} as={Link} to={`/productdetails/${e.id}`}>
        <Card.Img variant="right"  className="p_image" src={e.image} style={{width:'auto', maxHeight: '10rem',margin:'1rem'}} />
        <Card.Body as={Link} to={`/productdetails/${e.id}`} >
          
          <a style={{maxHeight:'3rem',marginBottom:'1rem'}}>{e.title}</a>
          <>
            <Card.Title>Rs:{e.price}/-</Card.Title>
          </>
          <Button variant="primary" as={Link} to={`/productdetails/${e.id}`} style={{marginTop:'2rem'}}>Details</Button>
          
        </Card.Body>
      </Card>
      </Col>
          
      ))}
      </Row>
        </Container>
        </div>
    )
}
