import React from 'react'
import { Redirect } from 'react-router-dom';

export default function ProtectedRoute(props) {
    console.log(props);
    let ProtectedCom = props.component;
    let isloggedin = window.localStorage.getItem('token')
    console.log(isloggedin);
    console.log(ProtectedCom);
    return (
        isloggedin ? (<ProtectedCom />) : (<Redirect to="/Login" />)
    )
}