import React from 'react'
import { BrowserRouter,Switch,Route } from "react-router-dom";
import Login from '../Components/Authentication/Login/Login';
import Logout from '../Components/Authentication/Logout';
import Reg from '../Components/Authentication/Registration/Reg';
import Nav from "../Layouts/Nav";
import ProtectedRoute from './ProtectedRouting';
import Productcategory from '../Components/Products/Productcategory/Productcategory';
import CatagoryDetails from '../Components/Products/Categorydetails/CatagoryDetails';
import Cart from '../Components/Cart/Cart';
import Layout from '../Layouts/Layout'
import ProductDetails from '../Components/Products/Productdetails/Productdetails'
import Footer from '../Layouts/footer'
import DisplaySlider from '../Layouts/DisplaySlider';
import Homepage from '../Layouts/Homepage/Homepage';
import Aboutus from '../Layouts/Homepage/Aboutus/Aboutus';

export default function Routes() {
    return (
        <div>
            <BrowserRouter>
          <Layout/>  
          <Switch>

                  <Route exact path='/' component={Homepage}/>  
                <Route path="/login" component={Login}/>
                <Route path="/reg" component={Reg}/>
                <Route path='/sidedrawer' component={Layout}/>
                <ProtectedRoute exact path="/logout" component={Logout}/>
                <Route exact path="/catDetails/:cname" component={CatagoryDetails}/>
                <Route exact path="/productdetails/:pid" component={ProductDetails}/>
                <ProtectedRoute exact path="/cart" component={Cart}/>
                <Route exact path='/aboutus' component={Aboutus}/>
          </Switch>
          <Footer/>
          </BrowserRouter>
        </div>
    )
}
