import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css'
import Routes from "./Routes/Routes";
//import Memo from "./Components/memo";
// import SideDrawer from './Layouts/SideDrawer'
function App() {
  return (
    <>
    {/* <SideDrawer/> */}
  <Routes/>
  {/* <Memo/> */}
    </>
  );
}

export default App;
