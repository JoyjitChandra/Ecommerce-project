import { ProductConst } from '../Action/ActionConst';
const initial = {
  AllCategories: [],
  Specific_Category: [],
  ProductDetails: [],
  Error: null,
  Message: "",
};
const ProductReducer = (state = initial, action) => {
    console.log(action);
  switch (action.type) {
    case `${ProductConst.PRODUCT_CATEGORY_GET}_REQUEST`:
      return state= {
        ...state,
      };
    case `${ProductConst.PRODUCT_CATEGORY_GET}_SUCCESS`:
      return state = {
        ...state,

        AllCategories: action.payload.categarydata,
        Message:action.payload.message
      };

    case `${ProductConst.PRODUCT_CATEGORY_GET}_FAILURE`:
      return state = {
        ...state,
        Error: action.payload.message,
      };
      case `${ProductConst.SPECIFIC_CATAGORY_DATA}_REQUEST`:
    return state= {
      ...state,
    };
  case `${ProductConst.SPECIFIC_CATAGORY_DATA}_SUCCESS`:
    return state = {
      ...state,

      Specific_Category: action.payload.categorydata,
      Message:action.payload.message
    };

  case `${ProductConst.SPECIFIC_CATAGORY_DATA}_FAILURE`:
    return state = {
      ...state,
      Error: action.payload.message,
    };
    case `${ProductConst.PRODUCT_DETAILS}_REQUEST`:
      return state={
        ...state
      }
      case `${ProductConst.PRODUCT_DETAILS}_SUCCESS`:
      return state={
        ...state,
        Message:action.payload.message
      }
      case `${ProductConst.PRODUCT_DETAILS}_FAILURE`:
        return state={
          ...state,
          Error:action.payload.message
        }

    default:
      return state;
  }
};

export default ProductReducer;

