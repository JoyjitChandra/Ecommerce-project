import react from 'react'
import {CartConst} from '../Action/ActionConst'
import {toast} from 'react-toastify';
const initial ={
   products:[],
    error:null,
    message:''
}

const CartReducer=(state=initial,action)=>{
    const pds=state.products;
    switch (action.type) {
        case `${CartConst.PRODUCT_CART}_SUCCESS`:
            const prod_presence=pds.find(({id})=>id==action.payload.products.id);
           // console.log(prod_presence);
           

              

            if(prod_presence !== undefined){
            const prod_presence2={...prod_presence,qty:prod_presence.qty+1};
            //console.log(prod_presence2);
            const summerFruitsCopy = pds.map(elem => 
                elem .id === prod_presence.id ? 
                    {...elem,qty:prod_presence.qty+1} : elem );

               

                state={
                    ...state,
                    products: summerFruitsCopy
                }
               
                toast.success('🦄 product added !', {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                    });
           // console.log(product.products);

                return state;

            }else{

                action.payload.products['qty']=1;
                pds.push(action.payload.products)
               state={
                    ...state,
                    products: pds
                }

                toast.success('Added To Cart', {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                    });
             
            //console.log(product.products);

                return state;
            }
        case `CART_INCS_SUCCESS`:
         // const updt_prod={...action.payload.products,qty:action.payload.products.qty+1} 
          const aftrIncArr = pds.map(elem => 
            elem .id === action.payload.products.id ? 
                {...elem,qty:action.payload.products.qty+1} : elem );

           state={
                    ...state,
                    products: aftrIncArr
                }
            console.log(state);
            return state;
        case `CART_DESC_SUCCESS`:
         // const updt_prod={...action.payload.products,qty:action.payload.products.qty+1} 
          const aftrDesArr = pds.map(elem => 
           elem.qty > 1 && elem .id === action.payload.products.id ? 
                {...elem,qty:action.payload.products.qty-1} : elem );

                state={
                    ...state,
                    products: aftrDesArr
                }
           // console.log(product);
            return state;

        case `CART_DELT_SUCCESS`:
        
        const filteredItem = pds.filter((item) => item.id != action.payload.products.id);
       
        state={
                    ...state,
                    products: filteredItem
                }
            return state;
            
        case `${CartConst.PRODUCT_CART}_FAILURE`:
            state={
                ...state,
                error:action.payload.error
            }
            return state;
            
            default:
                return state;
                
    }
}
export default CartReducer;