import { combineReducers } from "redux";
import AuthReducers from "./authReducers";
import ProductReducer from './ProductReducer'
import CartReducer from './CartReducer'
const rootReducer=combineReducers(
{
    authData:AuthReducers,
    productData: ProductReducer,
    cartData: CartReducer
})
export default rootReducer;