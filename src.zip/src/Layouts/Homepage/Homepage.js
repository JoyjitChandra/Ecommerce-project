import React ,{ useEffect,useState }from 'react'
import {Carousel,CarouselItem,Caption} from 'react-bootstrap'
import './Homepage.css'
import './Aboutus/Aboutus'
import Aboutus from './Aboutus/Aboutus'
import Aos from 'aos';
import 'aos/dist/aos.css'
import './Aboutus/AboutUs.css'
import { ProductCate } from '../../Action/ProductAction';
import { useDispatch, useSelector } from "react-redux";
export default function Homepage() {
  const [category,setCategory] = useState('Categories')
  const DispatchMethod = useDispatch();
  const ProductCategory = useSelector((state) => state.productData);
  console.log(ProductCategory);
  useEffect(() => {
    DispatchMethod(ProductCate());
  },[DispatchMethod]);
  

    return (
        <div>
          <div >
            <Carousel fade className='mycarousel'>
  <CarouselItem interval={2000}>
    <img className="d-block w-100" src='https://getyourtips.com/wp-content/uploads/2015/12/Online-Gadget-Shopping-Tips.jpg'  alt="First slide"/>
    <Carousel.Caption>
      <h3 href="">Electronics</h3>
      <p>Enjoy shopping with Oceancart! :)</p>
    </Carousel.Caption>
  </CarouselItem>
  <CarouselItem interval={2500}>
    <img
      className="d-block w-100"
      src="https://www.vertebrae.com/wp-content/uploads/2020/06/3d-augmented-reality-ecommerce-for-jewelry-1536x699.png"
      alt="Second slide"
    />

    <Carousel.Caption>
      <h3>Jewelry</h3>
      <p>Enjoy shopping with Oceancart! :)</p>
    </Carousel.Caption>
  </CarouselItem>
  <CarouselItem interval={3000}>
    <img
      className="d-block w-100"
      src='https://th.bing.com/th/id/Rc5c1b96dc6f82dd2fe7a4c69bf19b453?rik=9WrySfGGqW%2f9KQ&riu=http%3a%2f%2fksassets.timeincuk.net%2fwp%2fuploads%2fsites%2f46%2f2017%2f06%2fclothes.jpg&ehk=qGH4%2fOwj7MJQqSwi0BsTEpm6T%2fqFYOPtN9SWShNi5ik%3d&risl=&pid=ImgRaw'
      alt="Third slide"
    />
    <Carousel.Caption>
      <h3>Cloths</h3>
      <p>Enjoy shopping with Oceancart! :)</p>
    </Carousel.Caption>
  </CarouselItem>
</Carousel>
</div>
<div class='abouts'>
<Aboutus/>
</div>
        </div>
    )
}
