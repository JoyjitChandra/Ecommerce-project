import React from 'react'
import './AboutUs.css'
export default function Aboutus() {
    return (
        <div className='abouts'>
            <h1>About Us</h1>
            <p>OceanCart is guided by four principles: customer obsession rather than competitor focus, passion for invention, commitment to operational excellence, and long-term thinking. OceanCart strives to be The Best Customer-Centric Company,The Best Employer, and Earth’s Safest Place to Work. Customer reviews, 1-Click shopping, personalized recommendations, Prime, Fulfillment by OceanCart, Career Choice, and The Climate Pledge are some of the things pioneered by Oceancart.</p>
        </div>
    )
}
