import React from "react";
import "./styles.css";
import { Link, Route } from "react-router-dom";
import { Button ,NavLink} from "react-bootstrap";
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
import { makeStyles } from '@material-ui/core/styles';
export default function Nav(props) {
  const useStyles = makeStyles((theme) => ({
    root: {
      flexGrow: 1,
    },
    menuButton: {
      marginRight: theme.spacing(2),
    },
    title: {
      flexGrow: 1,
    },
  }));

  return (
    <div>
      <header className="Navbar">
        <div className="Toolbar">
        <Button edge="start"  as={Link} to='/sidedrawer' color="inherit" aria-label="menu" >
      <MenuIcon  />
    </Button>
          <div className="Title">
            <NavLink style={{color:'#ffffff'}} as={Link}  to='/'>HOME</NavLink>
          </div>
          <div>
          <Button style={{color:'#ffffff'}} className="product"  as={Link} to="/productCatagory">Product</Button>
              {/* <Button style={{color:'#ffffff'}} className="reg" variant="outline-success" as={Link} to="/reg">Sign Up</Button> */}
            {/* <Button style={{color:'#ffffff'}} className="login" variant="outline-success" as={Link} to="/login"> Login </Button> */}
            {/* <Button style={{color:'#ffffff'}} className="logout" variant="outline-success" as={Link} to="/logout"> Logout </Button> */}
            <NavLink as={Link}  to='user'>User
            <select id = "myList" onchange = "favTutorial()" >  
            <option className="login" as={Link} to="/login"> Login</option>  
            <option  className="reg" as={Link} to="/reg" >Register</option>  
            <option className="logout"  as={Link} to="/logout"> Logout</option>  
            </select></NavLink>  
          </div>
        </div>
      </header>
      <div className="Toolbar" />

    </div>
  );
}
