import React from 'react'

export default function DisplaySlider() {
    return (
        <div>
            
        </div>
    )
}
