
import {CartConst} from './ActionConst'
import axios from 'axios'

export const AddToCart=(pdetails)=>{
    return async (dispatch)=>{
        dispatch({type:`${CartConst.PRODUCT_CART}_REQUEST`});
                axios.post(`https://fakestoreapi.com/carts`,pdetails).then((response)=>{
                        console.log(response);
                        
                        dispatch({type:`${CartConst.PRODUCT_CART}_SUCCESS`,payload:{message:"SUCCESSFUL", products:pdetails}});
                }).catch(()=>{
                        dispatch({type:`${CartConst.PRODUCT_CART}_FAILURE`,payload:{error:"FAILED"}})
                })
    }
}

export const CartProdIncDcs=(cart_prod_sngl)=>{
 
        switch (cart_prod_sngl.action) {
            case 'decrease':
                return async(dispatch)=>{
    
                    dispatch({
                        type:`CART_DESC_SUCCESS`,
                        payload:{
                            message:"Add product in Cart",
                            products:cart_prod_sngl.s_product
                        }
                    })
    
                }
    
            case 'increase':
                return async(dispatch)=>{
    
                    dispatch({
                        type:`CART_INCS_SUCCESS`,
                        payload:{
                              message:"Add product in Cart",
                            products:cart_prod_sngl.s_product
                        }
                    })
    
                }
            case 'delete':
                return async(dispatch)=>{
    
                    dispatch({
                        type:`CART_DELT_SUCCESS`,
                        payload:{
                            message:"Delete product in Cart",
                            products:cart_prod_sngl.s_product
                        }
                    })
    
                }
                
        
            default:
                break;
        }
    
     return (dispatch)=>{
      
    }
    }
    
    export default CartProdIncDcs;