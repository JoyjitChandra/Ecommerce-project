import {authConstant} from './ActionConst';
import axios from "axios";
import { Redirect} from 'react-router-dom'
export const signUp=(user)=>{
return async (dispatch)=>{
    dispatch({type:`${authConstant.USER_REGISTER}_REQUEST`});
    axios.post('https://api09.herokuapp.com/register',user).then((res)=>{
        const msg=res.data.message
        console.log(res.data);
        //success action generated
        //dispatch(actionType,payLode(opt))
        
        dispatch({type:`${authConstant.USER_REGISTER}_SUCCESS`,payload:{message:msg}})
    }).catch((err)=>{
        //failure action generated
        dispatch({type:`${authConstant.USER_REGISTER}_FAILURE`,payload:{error:"Email already exists"}})
    })
}
}
export const signIn=(user)=>{

    return async (dispatch)=>{
        dispatch({type:`${authConstant.USER_LOGIN}_REQUEST`});
        axios.post('https://api09.herokuapp.com/login',user).then((res)=>{
            const msg=res.data.message
            console.log(res.data);
            const t=res.data.token
            window.localStorage.setItem('token',t)
            //success action generated
            //dispatch(actionType,payLode(opt))

            dispatch({type:`${authConstant.USER_LOGIN}_SUCCESS`,payload:{message:msg}})
        }).catch((err)=>{
            //failure action generated
            dispatch({type:`${authConstant.USER_LOGIN}_FAILURE`,payload:{error:"Invalid email or password"}})
        })
    }

}

export const Signout=(user)=>{
    return async (dispatch)=>{
        dispatch({type:`${authConstant.USER_LOGOUT}_REQUEST`});
        if(localStorage.getItem('token')!==""){
            localStorage.clear();
            dispatch({type:`${authConstant.USER_LOGOUT}_SUCCESS`,payload:{message:'logout'}})
        }
        else{
            dispatch({type:`${authConstant.USER_LOGOUT}_FAILURE`,payload:{message:'failed'}})
        }
    }
}