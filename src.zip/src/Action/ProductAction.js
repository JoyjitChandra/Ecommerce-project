import { ProductConst } from './ActionConst'
import axios from 'axios'
export const ProductCate=()=>{
   
        return async (dispatch)=>{
            
            dispatch({type:`${ProductConst.PRODUCT_CATEGORY_GET}_REQUEST`});
            axios.get(`https://fakestoreapi.com/products/categories`).then((res)=>{
            dispatch({type:`${ProductConst.PRODUCT_CATEGORY_GET}_SUCCESS`,payload:{message:"Successful",
            categarydata:res.data}})
            
            }).catch((err)=>{
              
            dispatch({type:`${ProductConst.PRODUCT_CATEGORY_GET}_FAILURE`,payload:{message:"Fail"}})
            
        
            })
            }
    }

    export const Specificdata=(cname)=>{
            return async (dispatch)=>{
        dispatch({type:`${ProductConst.SPECIFIC_CATAGORY_DATA}_REQUEST`});
        axios.get(`https://fakestoreapi.com/products/category/${cname}`).then((res)=>{console.log(res.data);
        dispatch({type:`${ProductConst.SPECIFIC_CATAGORY_DATA}_SUCCESS`,payload:{message:"Successful",
        categorydata:res.data}})
        
        }).catch((err)=>{
          
        dispatch({type:`${ProductConst.SPECIFIC_CATAGORY_DATA}_FAILURE`,payload:{message:"Fail"}})
        })
}
    }


    export const ProductDet=(pid)=>{
        return async (dispatch)=>{
                dispatch({type:`${ProductConst.PRODUCT_DETAILS}_REQUEST`});
                axios.get(`https://fakestoreapi.com/products/${pid}`).then((response)=>{
                        console.log(response);
                        dispatch({type:`${ProductConst.PRODUCT_DETAILS}_SUCCESS`,payload:{message:"SUCCESSFUL", pdetails:response.data}});
                }).catch(()=>{
                        dispatch({type:`${ProductConst.PRODUCT_DETAILS}_FAILURE`,payload:{message:"FAILED"}})
                })
        }
    }